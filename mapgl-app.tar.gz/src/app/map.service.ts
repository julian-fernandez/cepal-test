import { Injectable } from '@angular/core';
import mapboxgl from 'mapbox-gl';
import { environment } from '../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';
@Injectable({
  providedIn: 'root',
})
export class MapService {
  map!: mapboxgl.Map;
  style = 'mapbox://styles/mapbox/streets-v11';
  lat = 35.0116;
  lng = 80.7681;
  zoom = 11;
  json: any;
  constructor(private http: HttpClient) {
    mapboxgl.accessToken = environment.mapbox.accessToken;
  }
  buildMap() {
    this.map = new mapboxgl.Map({
      container: 'map',
      style: 'mapbox://styles/ffirpo/ckkcxtf162clq17nis548dlzv',
      center: [-87.637596, 41.940403],
      zoom: 11,
    });

    this.map.addControl(new mapboxgl.NavigationControl());
    this.getGeoJson();
  }

  getGeoJson() {
    this.http.get('assets/chicago-parks.geojson').subscribe((json: any) => {
      this.json = json;
      console.log(this.json);
      this.json.features.forEach((marker) => {
        // create a HTML element for each feature
        /*var el = document.createElement('div');
        el.className = 'marker';
        console.log(marker.geometry.coordinates);
        new mapboxgl.Marker()
          .setLngLat(marker.geometry.coordinates)
          .addTo(this.map);*/
        var popup = new mapboxgl.Popup({ offset: 25 }).setText(
          'lorem ipsum asjdkas <b>asjsad</b> <h2>aaaaa</h2>'
        );
        var el = document.createElement('div');
        el.id = 'marker';
        new mapboxgl.Marker({
          draggable: true
        })
          .setLngLat(marker.geometry.coordinates)
          .setPopup(popup)
          .addTo(this.map);
      });
    });
  }
}
